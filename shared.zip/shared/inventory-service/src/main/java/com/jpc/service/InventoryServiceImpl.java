package com.jpc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpc.dao.InventoryRepository;
import com.jpc.model.Inventory;
@Service
public class InventoryServiceImpl implements InventoryService{

	@Autowired
	InventoryRepository inventoryRepository;
	
	@Override
	public void addProduct(Inventory inventory) {
		
		inventoryRepository.save(inventory);
	}

	@Override
	public Inventory checkProductInDB(String productId) {
		
		Inventory inventory = inventoryRepository.getByProductId(productId);
		
		return inventory;
	}

}
