package com.jpc.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "inventory")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Inventory {
	
	@Id
	@Column(name="product_id")
	private String productId;
	@Column(name="product_name")
	private String prodcutName;
	@Column(name="product_quantity")
	private int productQuantity;
	@Column(name="user_id")
	private String userId;

}
