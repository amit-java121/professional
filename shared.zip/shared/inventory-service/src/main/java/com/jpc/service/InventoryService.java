package com.jpc.service;

import com.jpc.model.Inventory;

public interface InventoryService {

	void addProduct(Inventory inventory);

	Inventory checkProductInDB(String productId);

}
