package com.jpc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpc.model.Inventory;
import com.jpc.service.InventoryService;

@RestController
@RequestMapping("/api/inventory")
public class InventoryServiceController {

	@Autowired
	InventoryService inventoryService;
	
	@Value("${server.port}")
	private String portNumbar;
	
	@PostMapping("/add-product")
	public String addPorduct(@RequestBody Inventory inventory) {
		
		inventoryService.addProduct(inventory);
		
		return "successfully added product!!";
	}
	
	@GetMapping("/check-quanity/{productId}")
	public Inventory checkProductQuantity(@PathVariable("productId") String productId) {

		System.out.println("running port number::::::"+portNumbar);
		
		return inventoryService.checkProductInDB(productId);

	}
	
}
