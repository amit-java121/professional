package com.jpc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpc.model.User;
import com.jpc.service.AccountService;
import com.jpc.service.JwtUtils;

@RestController
@RequestMapping("/api/account")
public class AccountServiceController {
	
	@Autowired
	AccountService accountService;
	
	@PostMapping("/register")
	public User registerUser(@RequestBody User user) {
		
		
		return accountService.saveUserDetails(user);
	}
	
	@GetMapping("/validate")
	public String validateToken() {
		User user = new User();
		user.setUserName("amit");
		return JwtUtils.generateToken(user);
	}

}
