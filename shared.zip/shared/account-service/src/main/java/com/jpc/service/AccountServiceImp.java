package com.jpc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.jpc.dao.AccountServiceRepository;
import com.jpc.model.User;

@Service
public class AccountServiceImp implements AccountService{
	
	@Autowired
	AccountServiceRepository accountServiceRepository;
	
	@Autowired 
	PasswordEncoder passwordEncoder;

	@Override
	public User saveUserDetails(User user) {
		String encodedPass = encodePassword(user.getPassword());
		user.setPassword(encodedPass);
		return accountServiceRepository.save(user);
	}

	
	private String encodePassword(String password) {
		String encodedPasswprd = passwordEncoder.encode(password);
		return encodedPasswprd;
	}
}
