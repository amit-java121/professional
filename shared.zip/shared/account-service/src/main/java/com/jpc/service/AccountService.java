package com.jpc.service;

import com.jpc.model.User;

public interface AccountService {

	User saveUserDetails(User user);

}
