package com.jpc.service;

import com.jpc.model.User;

public interface AccountService {

	User saveUserDetails(User user);

	String getToken(User user);

	String validateToken(String token,String username);

}
