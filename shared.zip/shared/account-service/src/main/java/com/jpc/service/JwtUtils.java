package com.jpc.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.jpc.model.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtils {
	
	
	public static String generateToken(User user) {
		Map<String, Object> claims = new HashMap<>();
		
		return createToken(claims, user.getUserName());
	}

	private static String createToken(Map<String, Object> claims, String userName) {


		return Jwts.builder().setClaims(claims).setSubject(userName).
				setIssuedAt(new Date(System.currentTimeMillis())).
				setExpiration(new Date(System.currentTimeMillis()+1000*60*10)).
				signWith(SignatureAlgorithm.HS256, "amit123").compact();
	}

}
