package com.jpc.filter;

import java.util.List;
import java.util.function.Predicate;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;

@Component
public class UrlValidator {
	
	public static final List<String> endpoints = List.of("/api/account/register","/api/account/login"); 
	
	
	public Predicate<ServerHttpRequest> secured = request -> 
	endpoints.stream().noneMatch(url -> request.getURI().getPath().contains(url));

}
