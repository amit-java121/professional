package com.jpc.filter;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.stereotype.Component;

@Component
public class AuthenticationFilter extends AbstractGatewayFilterFactory<AuthenticationFilter.Configuration> {
	
	@Autowired
	UrlValidator urlValidator;
	
	@Autowired
	JwtUtils jwtUtils;
	
	
	public AuthenticationFilter() {
		super(Configuration.class);
	}
	
	public static class Configuration{
		
	}

	@Override
	public GatewayFilter apply(Configuration config){
		

		return ((exchange,chain) ->{
			
			if(urlValidator.secured.test(exchange.getRequest())) {
				
				//check the header
				
				String authHeader = exchange.getRequest().getHeaders().get(org.springframework.http.HttpHeaders.AUTHORIZATION).get(0);
				
				if(authHeader != null && authHeader.startsWith("Bearer ")) {
					
					authHeader = authHeader.substring(7);
				}
				try {
					jwtUtils.validateToken(authHeader, "ak2@gmail.com");
				}catch(Exception e) {
					throw new RuntimeException("you are not authorized!!!!!!!!!!!!!!!");
				}
			}
			
			
			return chain.filter(exchange);
		});
	}

}
