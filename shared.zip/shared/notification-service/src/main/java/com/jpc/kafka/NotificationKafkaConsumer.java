package com.jpc.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.jpc.email.EmailSenderService;

@Component
public class NotificationKafkaConsumer {
	
	@Autowired
	EmailSenderService emailSenderService; 
	
	@KafkaListener(topics = "${spring.kafka.topic.name}", groupId = "${spring.kafka.consumer.group-id}")
	public void consumeMessage(String message) {
		System.out.println("Message recieved ::::::::::::::::"+message);
		//after receiving message, send email
		emailSenderService.sendEmail("prashantkolekarofficial@gmail.com", "javapluscloud@gmail.com", "Your order has been placed!!", message);
	}

}
