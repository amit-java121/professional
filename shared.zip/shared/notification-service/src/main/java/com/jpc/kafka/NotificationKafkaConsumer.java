package com.jpc.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class NotificationKafkaConsumer {
	
	@KafkaListener(topics = "${spring.kafka.topic.name}", groupId = "${spring.kafka.consumer.group-id}")
	public void consumeMessage(String message) {
		System.out.println("Message recieved ::::::::::::::::"+message);
		//after receiving message, send email
	}

}
