package com.jpc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpc.model.Product;
import com.jpc.service.ProductService;

@RestController
@RequestMapping("/api/product-service")
public class ProductServiceController {
	
	@Autowired
	ProductService productService;
	
	@PostMapping("/add-product")
	public void addProduct(@RequestBody Product product) {
		
		productService.addProduct(product);
	}

}
