package com.jpc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpc.model.Product;
import com.jpc.service.ProductService;

@RestController
@RequestMapping("/api/product-service")
public class ProductServiceController {
	
	@Autowired
	ProductService productService;
	
	@PostMapping("/add-product")
	public Product addProduct(@RequestBody Product product) {
		
		return productService.addProduct(product);
	}
	
	@GetMapping("/get-all-product")
	public List<Product> getAllProduct(){
		
		return productService.getAllProducts();
		
	}
	
	@GetMapping("/place-order/{productId}/{userId}")
	public String palceOrder(@PathVariable("productId") final String productId,@PathVariable("userId") final String userId) {
		
		return productService.placeOrder(productId,userId);
	}
	

}
