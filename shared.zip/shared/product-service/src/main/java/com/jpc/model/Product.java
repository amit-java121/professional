package com.jpc.model;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Product {
	
	private String productId;
	private String productName;
	private String productDesc;
	private Instant productCreateDate;
	

}
