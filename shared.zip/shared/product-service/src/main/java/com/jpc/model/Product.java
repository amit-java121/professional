package com.jpc.model;

import java.time.Instant;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Document
public class Product {
	
	@Id
	private String productId;
	private String productName;
	private double productPrice;
	private String productDesc;
	private Instant productCreateDate;
	private int totalQuantity;
	private String userId;
	

}
