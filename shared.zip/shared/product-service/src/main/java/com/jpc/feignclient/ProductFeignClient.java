package com.jpc.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import com.jpc.model.Product;

@FeignClient(name = "http://ORDER-SERVICE/api/order")
public interface ProductFeignClient {
	
	@PostMapping("/my-order")
	public String placeOrder(Product product);

}
