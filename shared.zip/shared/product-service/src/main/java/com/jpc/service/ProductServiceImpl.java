package com.jpc.service;

import org.springframework.stereotype.Service;
import com.jpc.model.Product;

@Service
public class ProductServiceImpl implements ProductService{
	
//	@Autowired
//	ProductRepository productRepository;
	
	@Override
	public void addProduct(Product product) {
	
		
	}

}
