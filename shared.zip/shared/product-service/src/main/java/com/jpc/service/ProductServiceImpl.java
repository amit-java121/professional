package com.jpc.service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpc.dao.ProductRepository;
import com.jpc.feignclient.ProductFeignClient;
import com.jpc.model.Product;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	ProductFeignClient productFeignClient;
	
	@Override
	public Product addProduct(Product product) {
	
		product.setProductCreateDate(Instant.now());
		
		return productRepository.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		
		return productRepository.findAll();
	}
	

	@Override
	public void placeOrder(final String productId) {
		
		Product product = getProductById(productId);
		
		//call Order service
		productFeignClient.placeOrder(product);
		
		
	}
	
	
	private Product getProductById(final String productId) {

		Optional<Product> product = productRepository.findById(productId);
		if (product.isEmpty()) {
			new Product();
		}

		return product.get();

	}

}
