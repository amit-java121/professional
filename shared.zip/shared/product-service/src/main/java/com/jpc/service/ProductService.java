package com.jpc.service;

import com.jpc.model.Product;

public interface ProductService {

	void addProduct(Product product);

}
