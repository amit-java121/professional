package com.jpc.service;

import java.util.List;

import com.jpc.model.Product;

public interface ProductService {

	Product addProduct(Product product);

	List<Product> getAllProducts();

	void placeOrder(final String productId);

}
