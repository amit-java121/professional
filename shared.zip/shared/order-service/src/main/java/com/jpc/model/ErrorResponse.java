package com.jpc.model;

import lombok.Data;

@Data
public class ErrorResponse {
	
	private int errorCode;
	private String errorMessage;
}
