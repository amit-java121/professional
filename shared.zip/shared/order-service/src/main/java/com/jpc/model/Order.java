package com.jpc.model;

import java.time.Instant;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "order_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {
	
	@Id
	@Column(name = "order_id")
	private String orderId;
	@Column(name = "user_id")
	private String userId;
	@Column(name = "product_id")
	private String productId;
	@Column(name = "product_name")
	private String productName;
	@Column(name = "purchage_date")
	private Instant purchageDate;
	@Column(name = "order_status")
	private String orderStatus;
	

}
