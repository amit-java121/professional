package com.jpc.model;

import java.time.Instant;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Product {
	
	private String productId;
	private String productName;
	private double productPrice;
	private String productDesc;
	private Instant productCreateDate;
	private int totalQuantity;
	private String userId;
}
