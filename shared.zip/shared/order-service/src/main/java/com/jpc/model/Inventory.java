package com.jpc.model;

import lombok.Data;

@Data
public class Inventory {
	
	private String productId;
	private String prodcutName;
	private int productQuantity;
	private String userId;

}
