package com.jpc.service;

import com.jpc.model.Order;

public interface OrderService {

	void saveOrder(Order order);

}
