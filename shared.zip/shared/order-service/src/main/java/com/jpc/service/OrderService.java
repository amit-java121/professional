package com.jpc.service;

import com.jpc.model.Order;
import com.jpc.model.OrderResponse;

public interface OrderService {

	OrderResponse saveOrder(Order order);

}
