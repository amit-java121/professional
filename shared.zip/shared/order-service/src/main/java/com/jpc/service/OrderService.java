package com.jpc.service;

import java.util.List;

import com.jpc.model.Order;
import com.jpc.model.Product;

public interface OrderService {

	List<Order> getOrders();

	String myOrder(Product product);

}
