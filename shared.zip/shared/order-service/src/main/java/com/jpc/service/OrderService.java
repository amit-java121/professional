package com.jpc.service;

import com.jpc.model.Order;
import com.jpc.model.OrderResponse;
import com.jpc.model.Product;

public interface OrderService {

	OrderResponse saveOrder(Order order);

	void myOrder(Product product);

}
