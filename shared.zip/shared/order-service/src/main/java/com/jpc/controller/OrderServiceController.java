package com.jpc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpc.model.Order;
import com.jpc.service.OrderService;

@RestController
@RequestMapping("/api/order")
public class OrderServiceController {
	
	@Autowired
	OrderService orderService;
	
	@PostMapping("/save-order")
	public void saveOrderDetails(@RequestBody Order order ) {
		
		orderService.saveOrder(order);
	}
	

}
