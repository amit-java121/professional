package com.jpc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpc.model.Order;
import com.jpc.service.OrderService;

@RestController
@RequestMapping("/api/order")
@RefreshScope
public class OrderServiceController {
	
	@Value("${test.user}")
	private String testName;
	
	@Autowired
	OrderService orderService;
	
	@PostMapping("/save-order")
	public void saveOrderDetails(@RequestBody Order order ) {
		
		orderService.saveOrder(order);
	}
	
	@GetMapping("/test")
	public void test() {
		System.out.println("value:::::::::  "+testName);
		
	}
	

}
