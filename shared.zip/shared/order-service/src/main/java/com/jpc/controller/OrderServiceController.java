package com.jpc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpc.model.Order;
import com.jpc.model.OrderResponse;
import com.jpc.service.OrderService;

@RestController
@RequestMapping("/api/order")
@RefreshScope
public class OrderServiceController {
	
	@Autowired
	Environment environment;
	
	@Value("${test.user}")
	private String testName;
	
	@Autowired
	OrderService orderService;
	
	@PostMapping("/save-order")
	public OrderResponse saveOrderDetails(@RequestBody Order order ) {
		
		return orderService.saveOrder(order);
	}
	
	@GetMapping("/test")
	public void test() {
		System.out.println("url:::::::"+environment.getProperty("spring.datasource.url"));
		//String ttt = environment.getRequiredProperty("spring.datasource.url123");
		//System.out.println("required::: "+ttt);
		System.out.println("value:::::::::  "+testName);
		
	}
	

}
