package com.jpc.feignclient;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.jpc.model.Inventory;

@FeignClient(name ="http://INVENTORY-SERVICE/api/inventory")
public interface OrderServiceFeignClient {
	
	@GetMapping("/check-quanity/{id}")
	public Inventory checkProductAvailablity(@PathVariable("id") String id);  

}
