package com.jpc.service;

import java.time.Instant;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.jpc.dao.OrderRepository;
import com.jpc.feignclient.OrderServiceFeignClient;
import com.jpc.model.Inventory;
import com.jpc.model.Order;
import com.jpc.model.OrderResponse;
import com.jpc.model.Product;

@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepository orderRepository;

	@Autowired 
	PaymentService paymentService;
	
	@Autowired
	OrderServiceFeignClient orderServiceFeignClient;
	
	@Override
	public OrderResponse saveOrder(Order order) {
		OrderResponse orderResponse = new OrderResponse();
		//before order 
		//check quantity
		if(checkAvailableProduct(order.getProductId(),order.getTotalQuantity())) {
			order.setOrderId(UUID.randomUUID().toString());
			order.setOrderStatus("success");
			order.setPurchageDate(Instant.now());
			
			Order od = orderRepository.save(order);
			orderResponse.setOrder(od);
			
			return orderResponse;
		}else {
			orderResponse.setErrorCode(404);
			orderResponse.setErrorMessage("product quantity is less then the order quanity");
			return orderResponse;
			
		}
		
		
	}
	
	private boolean checkAvailableProduct(String productId, int totalQyanity) {
		
		//service call (Inventory)
		//Inventory intventory = restTemplate.getForObject("http://INVENTORY-SERVICE/api/inventory/check-quanity/"+productId+"", Inventory.class);
		
		Inventory intventory = orderServiceFeignClient.checkProductAvailablity(productId);
		
		if(intventory != null && intventory.getProductQuantity() >= totalQyanity) {
			return true;
		}
		
		return false;
	}

	@Override
	public void myOrder(Product product) {
	
		if(checkAvailableProduct(product.getProductId(),product.getTotalQuantity())) {
			//call Payment service
			paymentService.doPaymnet("HDFC", "102020200202002020");
			
			//if payment is successful, save order and notify to the user
			//If payment id failed, will not save order, will notify to the user
			
			
		}
		
	}
	
	
	

}
