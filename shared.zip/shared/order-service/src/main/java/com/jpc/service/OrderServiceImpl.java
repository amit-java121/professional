package com.jpc.service;

import java.time.Instant;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpc.dao.OrderRepository;
import com.jpc.model.Order;

@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepository orderRepository;

	@Override
	public void saveOrder(Order order) {
		
		order.setOrderId(UUID.randomUUID().toString());
		order.setOrderStatus("success");
		order.setPurchageDate(Instant.now());
		
		orderRepository.save(order);
		
	}

}
