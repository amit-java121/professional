package com.jpc.service;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.jpc.dao.OrderRepository;
import com.jpc.feignclient.OrderServiceFeignClient;
import com.jpc.model.Inventory;
import com.jpc.model.Order;
import com.jpc.model.OrderResponse;
import com.jpc.model.Product;

@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepository orderRepository;

	@Autowired 
	PaymentService paymentService;
	
	@Autowired
	OrderServiceFeignClient orderServiceFeignClient;
	
	@Override
	public List<Order> getOrders() {

		return orderRepository.findAll();

	}
	
	private boolean checkAvailableProduct(String productId, int totalQyanity) {
		
		//service call (Inventory)
		//Inventory intventory = restTemplate.getForObject("http://INVENTORY-SERVICE/api/inventory/check-quanity/"+productId+"", Inventory.class);
		
		Inventory intventory = orderServiceFeignClient.checkProductAvailablity(productId);
		
		if(intventory != null && intventory.getProductQuantity() >= totalQyanity) {
			return true;
		}
		
		return false;
	}

	@Override
	public String myOrder(Product product) {
	            System.out.println("############################"+product);
		if(checkAvailableProduct(product.getProductId(),product.getTotalQuantity())) {
			//call Payment service
			String paymentMsg = paymentService.doPaymnet("HDFC", "102020200202002020");
			if(paymentMsg.equalsIgnoreCase("success")) {
				Order order = new Order();
				order.setOrderId(UUID.randomUUID().toString());
				order.setOrderStatus(paymentMsg);
				order.setProductId(product.getProductId());
				order.setProductName(product.getProductName());
				order.setPurchageDate(Instant.now());
				order.setTotalQuantity(product.getTotalQuantity());
				order.setUserId(product.getUserId());
		
				orderRepository.save(order);
				return "Order placed successful";
			}else{
				return "Order doesnt place, due to some reason!!";
				
			}			
			//if payment is successful, save order and notify to the user
			//If payment id failed, will not save order, will notify to the user

		}else {
			return "Requested Product is not available!!!";
		}
		
	}
	
	
	

}
