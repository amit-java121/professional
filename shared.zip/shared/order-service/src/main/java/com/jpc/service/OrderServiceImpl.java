package com.jpc.service;

import java.time.Instant;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.jpc.dao.OrderRepository;
import com.jpc.model.Inventory;
import com.jpc.model.Order;
import com.jpc.model.OrderResponse;

@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepository orderRepository;

	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public OrderResponse saveOrder(Order order) {
		OrderResponse orderResponse = new OrderResponse();
		//before order 
		//check quantity
		if(checkAvailableProduct(order.getProductId(),order.getTotalQuantity())) {
			order.setOrderId(UUID.randomUUID().toString());
			order.setOrderStatus("success");
			order.setPurchageDate(Instant.now());
			
			Order od = orderRepository.save(order);
			orderResponse.setOrder(od);
			
			return orderResponse;
		}else {
			orderResponse.setErrorCode(404);
			orderResponse.setErrorMessage("product qhatnity is less then the order quanity");
			return orderResponse;
			
		}
		
	}
	
	private boolean checkAvailableProduct(String productId, int totalQyanity) {
		
		//service call (Inventory)
		Inventory intventory = restTemplate.getForObject("http://INVENTORY-SERVICE/api/inventory/check-quanity/"+productId+"", Inventory.class);
		
		if(intventory != null && intventory.getProductQuantity() >= totalQyanity) {
			return true;
		}
		
		return false;
	}

}
