package com.jpc.service;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class PaymentService {
	
	
	public String doPaymnet(String bankName, String cardNumber) {
		//payment logic
		
		return new Random().nextBoolean() ? "Success":"Failed";
	} 

}
