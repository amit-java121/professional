package com.jpc.service;

import org.springframework.stereotype.Component;

@Component
public class PaymentService {
	
	
	public void doPaymnet(String bankName, String cardNumber) {
		//payment logic
	} 

}
