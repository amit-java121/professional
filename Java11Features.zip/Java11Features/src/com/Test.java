package com;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
	
	public static void main(String[] args) {
		
		String str =" hello ";
		
		//System.out.println(str.repeat(10));
		
		//isBlank()//isEmpty()
		
		if(str.isEmpty()) {
			System.out.println("inside if::");
		}
		
		if(str.isBlank()) {
			System.out.println("inside if::");
		}
		
		//trim()//strip()
		
		//str.stripTrailing()
		//str.stripLeading();
		//String str1 = "hello\nhi\nhello";
		
		//String lines() method
		
		//List<String> list = str1.lines().filter(a -> a!= null).collect(Collectors.toList());
		//System.out.println(list);
		//str1.lines().forEach(a ->System.out.println(a));
		
		
		//Convert object into array
		List<String> listStr =  new ArrayList<String>();
		listStr.add("hi1");
		listStr.add("hi2");
		listStr.add("hi3");
		
		String[] strArray = listStr.toArray(new String[listStr.size()]);
		System.out.println(strArray.toString());
		//introduce in java 11
		String[] strNew= listStr.toArray(String[]::new);
		
		System.out.println(strNew);
		for(String str1 : strNew) {
			System.out.println(str1);
		}
		
	}

}
