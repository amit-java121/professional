package com;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class TestSyncHttpClient {
	
	HttpClient httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
	
	public void callApi() throws IOException, InterruptedException {
		
		String url = "http://localhost:9090/user/login?username=amit&password=amit123";
		URI uri = URI.create(url);
		
		HttpRequest httpRequest = HttpRequest.newBuilder(uri).GET().build();
		
		HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
		
		System.out.println(response.statusCode());
		System.out.println(response.body());
		
		
		
	}

	public static void main(String[] args) {
		 
		TestSyncHttpClient testSyncHttpClient = new TestSyncHttpClient();
		try {
			testSyncHttpClient.callApi();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
